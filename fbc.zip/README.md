# accountkit-js
This is a sample implementation of AccountKit using the JS SDK and a PHP server
